import blockchain.Block;
import blockchain.Blockchain;

public class Main {

    public static void main(String[] args) {

        Blockchain blockchain = new Blockchain();

        Block block1 = new Block(
            1,
            "P001",
            "Laptop",
            "Supplier",
            "Manufacturer",
            100,
            "0"
        );

        Block block2 = new Block(
            2,
            "P002",
            "Mobile",
            "Manufacturer",
            "Distributor",
            200,
            block1.getHash()
        );

        Block block3 = new Block(
            3,
            "P003",
            "Tablet",
            "Distributor",
            "Retailer",
            150,
            block2.getHash()
        );

        blockchain.addBlock(block1);
        blockchain.addBlock(block2);
        blockchain.addBlock(block3);

        blockchain.displayChain();

        if (blockchain.isChainValid()) {
            System.out.println("Blockchain Status: VALID");
        } else {
            System.out.println("Blockchain Status: INVALID");
        }
    }
}