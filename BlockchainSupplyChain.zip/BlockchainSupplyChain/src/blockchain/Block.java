package blockchain;

import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;

public class Block {

    private int blockId;
    private String productId;
    private String productName;
    private String sender;
    private String receiver;
    private int quantity;
    private LocalDateTime timestamp;
    private String previousHash;
    private String hash;

    public Block(int blockId, String productId, String productName,
                 String sender, String receiver, int quantity,
                 String previousHash) {

        this.blockId = blockId;
        this.productId = productId;
        this.productName = productName;
        this.sender = sender;
        this.receiver = receiver;
        this.quantity = quantity;
        this.timestamp = LocalDateTime.now();
        this.previousHash = previousHash;
        this.hash = calculateHash();
    }

    public String calculateHash() {
        try {
            String data = blockId + productId + productName +
                    sender + receiver + quantity +
                    timestamp + previousHash;

            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(data.getBytes(StandardCharsets.UTF_8));

            StringBuilder result = new StringBuilder();

            for (byte b : bytes) {
                result.append(String.format("%02x", b));
            }

            return result.toString();

        } catch (Exception e) {
            return "Hash Error";
        }
    }

    public void display() {
        System.out.println("-----------------------------");
        System.out.println("Block ID: " + blockId);
        System.out.println("Product ID: " + productId);
        System.out.println("Product Name: " + productName);
        System.out.println("Sender: " + sender);
        System.out.println("Receiver: " + receiver);
        System.out.println("Quantity: " + quantity);
        System.out.println("Timestamp: " + timestamp);
        System.out.println("Previous Hash: " + previousHash);
        System.out.println("Current Hash: " + hash);
        System.out.println("-----------------------------");
    }

    public String getHash() {
        return hash;
    }

    public String getPreviousHash() {
        return previousHash;
    }
}