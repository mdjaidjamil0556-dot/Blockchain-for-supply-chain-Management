package blockchain;

import java.util.ArrayList;

public class Blockchain {

    private ArrayList<Block> chain;

    public Blockchain() {
        chain = new ArrayList<>();
    }

    public synchronized void addBlock(Block block) {
        chain.add(block);
        System.out.println("Block added successfully!");
    }

    public void displayChain() {
        System.out.println("\n===== SUPPLY CHAIN BLOCKCHAIN =====");

        for (Block block : chain) {
            block.display();
        }

        System.out.println("Total Blocks: " + chain.size());
    }

    public int getBlockCount() {
        return chain.size();
    }

    public boolean isChainValid() {
        for (int i = 1; i < chain.size(); i++) {
            Block currentBlock = chain.get(i);
            Block previousBlock = chain.get(i - 1);

            if (!currentBlock.getPreviousHash()
                    .equals(previousBlock.getHash())) {
                return false;
            }
        }

        return true;
    }
}