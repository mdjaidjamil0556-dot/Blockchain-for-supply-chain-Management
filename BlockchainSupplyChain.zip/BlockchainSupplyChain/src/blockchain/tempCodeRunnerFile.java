        System.out.println("Block added successfully!");
    }

    /**
     * Displays all blocks stored in the blockchain.
     */
    public synchronized void displayChain() {
        System.out.println("\n===== SUPPLY CHAIN BLOCKCHAIN =====");

        for (Block block : chain) {
            block.display();
        }

        System.out.println("Total Blocks: " + chain.size());
    }

    /**
     * Returns the total number of blocks.
     *
     * @return number of blocks
     */
    public synchronized int getBlockCount() {
        return chain.size();
    }

    /**
     * Checks whether the blockchain's hashes and links are valid.
     *
     * @return true if all checked hashes and links are valid
     */
    public synchronized boolean isChainValid() {

        // An empty blockchain is valid.
        if (chain.isEmpty()) {
            return true;
        }

        // Verify the first block's stored hash.
        Block firstBlock = chain.get(0);

        if (!firstBlock.calculateHash().equals(firstBlock.getHash())) {
            return false;
        }

        // Verify the remaining blocks and their previous-hash links.
        for (int i = 1; i < chain.size(); i++) {

            Block currentBlock = chain.get(i);
            Block previousBlock = chain.get(i - 1);

            // Check whether the current block's stored hash is correct.
            if (!currentBlock.calculateHash().equals(currentBlock.getHash())) {