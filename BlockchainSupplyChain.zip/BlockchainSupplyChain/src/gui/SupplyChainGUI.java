package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

import blockchain.Block;
import blockchain.Blockchain;

public class SupplyChainGUI extends JFrame {

    private DefaultTableModel tableModel;
    private Blockchain blockchain;

    private int blockCounter = 1;
    private String previousHash = "0";

    public SupplyChainGUI() {

        blockchain = new Blockchain();

        setTitle("Blockchain Supply Chain Management");
        setSize(950, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel title = new JLabel(
                "BLOCKCHAIN SUPPLY CHAIN MANAGEMENT",
                SwingConstants.CENTER
        );

        title.setFont(new Font("Arial", Font.BOLD, 22));

        String[] columns = {
            "Product ID",
            "Product Name",
            "Sender",
            "Receiver",
            "Quantity",
            "Status",
            "Block Hash"
        };

        tableModel = new DefaultTableModel(columns, 0);
        JTable productTable = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(productTable);

        JButton addButton = new JButton("Add Product");
        JButton clearButton = new JButton("Clear Table");
        JButton validateButton = new JButton("Validate Blockchain");
        JButton viewButton = new JButton("View Blockchain");

        addButton.addActionListener(e -> addProduct());

        clearButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(
                    this,
                    "Products cannot be removed from the blockchain."
            );
        });

        validateButton.addActionListener(e -> validateBlockchain());

        viewButton.addActionListener(e -> blockchain.displayChain());

        JPanel buttonPanel = new JPanel();

        buttonPanel.add(addButton);
        buttonPanel.add(validateButton);
        buttonPanel.add(viewButton);
        buttonPanel.add(clearButton);

        setLayout(new BorderLayout(10, 10));

        add(title, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void addProduct() {

        JTextField idField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField senderField = new JTextField();
        JTextField receiverField = new JTextField();
        JTextField quantityField = new JTextField();

        Object[] fields = {
            "Product ID:", idField,
            "Product Name:", nameField,
            "Sender:", senderField,
            "Receiver:", receiverField,
            "Quantity:", quantityField
        };

        int result = JOptionPane.showConfirmDialog(
                this,
                fields,
                "Add Product",
                JOptionPane.OK_CANCEL_OPTION
        );

        if (result != JOptionPane.OK_OPTION) {
            return;
        }

        try {
            String id = idField.getText().trim();
            String name = nameField.getText().trim();
            String sender = senderField.getText().trim();
            String receiver = receiverField.getText().trim();

            int quantity = Integer.parseInt(
                    quantityField.getText().trim()
            );

            if (id.isEmpty() || name.isEmpty()
                    || sender.isEmpty() || receiver.isEmpty()
                    || quantity <= 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "Enter valid details and a positive quantity."
                );

                return;
            }

            Block block = new Block(
                    blockCounter,
                    id,
                    name,
                    sender,
                    receiver,
                    quantity,
                    previousHash
            );

            blockchain.addBlock(block);

            previousHash = block.getHash();

            tableModel.addRow(new Object[]{
                id,
                name,
                sender,
                receiver,
                quantity,
                "In Transit",
                block.getHash()
            });

            blockCounter++;

            JOptionPane.showMessageDialog(
                    this,
                    "Product added to blockchain successfully!"
            );

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Quantity must be a valid whole number."
            );
        }
    }

    private void validateBlockchain() {

        if (blockchain.isChainValid()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Blockchain Status: VALID"
            );
        } else {
            JOptionPane.showMessageDialog(
                    this,
                    "Blockchain Status: INVALID"
            );
        }
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            new SupplyChainGUI().setVisible(true);
        });
    }
}