package model;

public class ElectronicProduct extends Product {

    private int warrantyMonths;
    private String brand;

    public ElectronicProduct(String productId, String productName,
                             String category, int quantity,
                             String status, int warrantyMonths,
                             String brand) {

        super(productId, productName, category, quantity, status);

        this.warrantyMonths = warrantyMonths;
        this.brand = brand;
    }

    public int getWarrantyMonths() {
        return warrantyMonths;
    }

    public String getBrand() {
        return brand;
    }

    @Override
    public void displayDetails() {
        super.displayDetails();

        System.out.println("Brand: " + brand);
        System.out.println("Warranty: " + warrantyMonths + " months");
        System.out.println("--------------------------");
    }
}