package model;

public class PerishableProduct extends Product {

    private String expiryDate;
    private double storageTemperature;

    public PerishableProduct(String productId, String productName,
                             String category, int quantity,
                             String status, String expiryDate,
                             double storageTemperature) {

        super(productId, productName, category, quantity, status);

        this.expiryDate = expiryDate;
        this.storageTemperature = storageTemperature;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public double getStorageTemperature() {
        return storageTemperature;
    }

    @Override
    public void displayDetails() {
        super.displayDetails();

        System.out.println("Expiry Date: " + expiryDate);
        System.out.println("Storage Temperature: "
                + storageTemperature + " Celsius");
        System.out.println("--------------------------");
    }
}